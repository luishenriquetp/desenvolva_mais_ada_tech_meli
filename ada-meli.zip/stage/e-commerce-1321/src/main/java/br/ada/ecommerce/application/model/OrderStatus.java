package br.ada.ecommerce.application.model;

public enum OrderStatus {

    OPEN, PENDING_PAYMENT, PAID, SHIPPING, FINISH;

}
