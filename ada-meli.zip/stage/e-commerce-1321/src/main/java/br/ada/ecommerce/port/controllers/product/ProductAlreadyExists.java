package br.ada.ecommerce.port.controllers.product;

public class ProductAlreadyExists extends RuntimeException{


}
