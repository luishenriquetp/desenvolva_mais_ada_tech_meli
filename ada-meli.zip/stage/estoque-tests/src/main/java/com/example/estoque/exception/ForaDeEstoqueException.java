package com.example.estoque.exception;

public class ForaDeEstoqueException extends RuntimeException{
    public ForaDeEstoqueException(String mensagem) {
        super(mensagem);
    }
}
