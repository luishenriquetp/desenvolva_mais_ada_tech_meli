
public class Main {
    public static void main(String[] args) {
        Caixa<String> nome = new Caixa<>();
        nome.guardar("Luís");
        System.out.println(nome.pegar());
    }
}
