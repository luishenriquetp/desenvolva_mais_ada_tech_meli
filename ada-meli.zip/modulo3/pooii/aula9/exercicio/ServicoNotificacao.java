package br.com.pedro.aula9.exercicio;

public interface ServicoNotificacao {
    void servicoNotificacao();
}
