package br.com.pedro.aula9.exercicio;

public interface MetodoPagamento {
    void processarPagamento(String id, double valor);
}
