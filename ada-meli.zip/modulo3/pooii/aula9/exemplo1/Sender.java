package br.com.pedro.aula9.exemplo1;

public interface Sender {
    void send(String msgs);
}
