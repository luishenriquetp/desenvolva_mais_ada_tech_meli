package br.com.pedro.aula9.exemplo2;

public abstract class Teste {
}
