package br.com.pedro.aula9.exemplo2;

public interface MeioPagamentoOnline {
}
