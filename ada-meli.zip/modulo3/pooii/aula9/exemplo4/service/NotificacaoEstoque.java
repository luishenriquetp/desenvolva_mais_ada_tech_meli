package br.com.pedro.aula9.exemplo4.service;

import br.com.pedro.aula9.exemplo4.domain.Reserva;

public interface NotificacaoEstoque {

    public void reservarEstoque(Reserva reserva);
}
