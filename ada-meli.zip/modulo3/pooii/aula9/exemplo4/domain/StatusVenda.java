package br.com.pedro.aula9.exemplo4.domain;

public enum StatusVenda {

    PENDENTE,
    APROVADO,
    CANCELADO
}
