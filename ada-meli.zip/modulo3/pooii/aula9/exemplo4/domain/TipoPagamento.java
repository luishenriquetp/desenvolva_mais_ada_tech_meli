package br.com.pedro.aula9.exemplo4.domain;

public enum TipoPagamento {

    CARTAO_CREDITO,
    CARTAO_DEBITO,
    BOLETO_BANCARIO,
    PIX;
}
