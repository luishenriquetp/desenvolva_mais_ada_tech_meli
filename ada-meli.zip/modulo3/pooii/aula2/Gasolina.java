package br.com.pedro.aula2;

public class Gasolina {
}
