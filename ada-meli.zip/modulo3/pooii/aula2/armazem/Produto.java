package br.com.pedro.aula2.armazem;

public class Produto {

    private String nome;
}
