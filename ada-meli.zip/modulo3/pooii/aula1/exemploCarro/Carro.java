package br.com.pedro.aula1.exemploCarro;

public interface Carro {

    void acelerar();
    void frear();
    void trocarMarcha();
}
