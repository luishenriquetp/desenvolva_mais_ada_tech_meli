package br.com.pedro.aula1.exemploCarro;

public class CarroGM implements Carro{
    @Override
    public void acelerar() {
        System.out.println("Acelerando");
    }

    @Override
    public void frear() {
    }

    @Override
    public void trocarMarcha() {
    }
}
