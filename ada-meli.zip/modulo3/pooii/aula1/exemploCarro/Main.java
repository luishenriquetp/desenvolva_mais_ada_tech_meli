package br.com.pedro.aula1.exemploCarro;

public class Main {

    public static void main(String[] args) {
        Carro carro = new CarroGM();
    }
}
