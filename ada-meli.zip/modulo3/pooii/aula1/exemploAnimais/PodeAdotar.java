package br.com.pedro.aula1.exemploAnimais;

public interface PodeAdotar {
}
