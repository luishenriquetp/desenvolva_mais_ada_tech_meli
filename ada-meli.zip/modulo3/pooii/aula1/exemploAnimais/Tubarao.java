package br.com.pedro.aula1.exemploAnimais;

public class Tubarao implements Proibidos{
    @Override
    public void atacarPessoas() {

    }
}
