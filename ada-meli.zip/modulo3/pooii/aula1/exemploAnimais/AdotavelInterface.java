package br.com.pedro.aula1.exemploAnimais;

public interface AdotavelInterface {

    void proteger();
    void treinar();
}
