package br.com.pedro.aula1.exemploControleRemoto;

public class Main {

    public static void main(String[] args) {
        ControleRemoto controle = new ControleRemotoLG();
        ControleRemoto controlePhilco = new ControleRemotoPhilco();

    }
}
