package br.com.pedro.aula1.exemploControleRemoto;

public class ControleRemotoPhilco implements ControleRemoto{
    @Override
    public void ligar() {

    }

    @Override
    public void desligar() {

    }

    @Override
    public String trocarCanal(String numeroCanal) {
        return "";
    }

    @Override
    public String aumentarVolume() {
        return "";
    }

    @Override
    public String abaixarVolume() {
        return "";
    }

    @Override
    public String mute() {
        return "";
    }
}
