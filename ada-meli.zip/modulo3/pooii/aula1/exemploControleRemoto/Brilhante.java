package br.com.pedro.aula1.exemploControleRemoto;

public interface Brilhante {
}
