package br.com.pedro.aula1.exercicio;

public interface Imprimivel {

    void imprimir();
}
