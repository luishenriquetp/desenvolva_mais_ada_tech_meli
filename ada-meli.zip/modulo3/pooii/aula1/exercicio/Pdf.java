package br.com.pedro.aula1.exercicio;

public class Pdf implements Imprimivel{
    @Override
    public void imprimir() {
        System.out.println("Imprimir através do PDF");
    }
}
