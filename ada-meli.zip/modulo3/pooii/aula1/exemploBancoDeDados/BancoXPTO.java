package br.com.pedro.aula1.exemploBancoDeDados;

public class BancoXPTO implements BancoDeDados{
    @Override
    public void salvar(Pessoa pessoa) {

    }

    @Override
    public void alterar(Pessoa pessoa) {

    }

    @Override
    public void excluir(Pessoa pessoa) {

    }
}
