package br.com.pedro.aula1.exemploBancoDeDados;

public class Pessoa {

    private String nome;
    private String Rg;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRg() {
        return Rg;
    }

    public void setRg(String rg) {
        Rg = rg;
    }
}
