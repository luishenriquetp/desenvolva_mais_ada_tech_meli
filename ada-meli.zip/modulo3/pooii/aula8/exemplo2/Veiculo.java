package br.com.pedro.aula8.exemplo2;

public interface Veiculo {
    void dirigir();
    void acelerar();
    void frear();
    void decolar();
    void aterrissar();
}
