package br.com.pedro.aula7.exemplo1;

public class Carro extends VeiculoTerrestre{

    public Carro(String modelo) {
        super(modelo);
    }
}
