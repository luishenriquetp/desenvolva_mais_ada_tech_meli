package br.com.pedro.aula7.exemplo1;

public class Barco extends VeiculoNautico{

    public Barco(String modelo) {
        super(modelo);
    }
}
