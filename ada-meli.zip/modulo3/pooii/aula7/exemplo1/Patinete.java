package br.com.pedro.aula7.exemplo1;

public class Patinete extends Veiculo{

    public Patinete(String modelo) {
        super(modelo);
    }

}
