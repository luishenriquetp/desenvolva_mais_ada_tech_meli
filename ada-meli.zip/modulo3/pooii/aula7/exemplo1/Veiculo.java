package br.com.pedro.aula7.exemplo1;

public class Veiculo {

    protected String modelo = "";

    public Veiculo(String modelo){
        this.modelo = modelo;
    }

    public void metodoDeTeste(){
        System.out.println("Printar algo");
    }

}
