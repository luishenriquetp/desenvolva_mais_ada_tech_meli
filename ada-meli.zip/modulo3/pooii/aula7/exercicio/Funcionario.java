package br.com.pedro.aula7.exercicio;

public class Funcionario {
    void trabalhar(){
        System.out.println("Trabalhando...");
    }
    void baterPonto(){
        System.out.println("Ponto registrado.");
    }
    void fazerPausa(){
        System.out.println("Pausa para café.");
    }
    void atenderCliente(){
        System.out.println("Atendendo cliente.");
    }
    void programar(){
        System.out.println("Programando...");
    }
    void gerenciarProjeto(){
        System.out.println("Gerenciando projeto...");
    }
}

