package br.com.pedro.aula7.exemplo2;

public class AvesQueVoam extends Ave{

    public void voar() {
        System.out.println("Esta ave está voando!");
    }
}
