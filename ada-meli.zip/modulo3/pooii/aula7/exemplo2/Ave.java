package br.com.pedro.aula7.exemplo2;

public class Ave {

    public void alimentar(){
        System.out.println("Comendo");
    }
}
