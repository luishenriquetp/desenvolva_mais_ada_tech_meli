package br.com.pedro.aula7.exemplo2;

public class Pinguim extends Ave{

}
