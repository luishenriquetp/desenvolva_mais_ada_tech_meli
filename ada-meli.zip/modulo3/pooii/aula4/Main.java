package br.com.pedro.aula4;

public class Main {

    public static void main(String[] args) {

    }
}
