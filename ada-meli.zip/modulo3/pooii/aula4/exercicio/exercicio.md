📚 Exercício: Identificar e Corrigir Violações do SRP
A classe Pedido que viola o SRP ao acumular diversas responsabilidades. Sua tarefa é separar as responsabilidades em classes distintas, assim como foi feito no exemplo anterior.

Desafio:
Identifique as diferentes responsabilidades que a classe Pedido está assumindo.
Crie novas classes para isolar essas responsabilidades.
Mantenha a classe Pedido apenas com os atributos e comportamentos relacionados diretamente a um pedido.