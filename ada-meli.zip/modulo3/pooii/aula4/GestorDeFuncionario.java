package br.com.pedro.aula4;

public class GestorDeFuncionario {


}
