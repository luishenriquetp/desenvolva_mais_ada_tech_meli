package br.com.pedro.aula4;

public class RH {

    public void imprimirCracha(Funcionario funcionario) {
        System.out.println("Imprimindo crachá para " + funcionario.getNome());
    }
}
