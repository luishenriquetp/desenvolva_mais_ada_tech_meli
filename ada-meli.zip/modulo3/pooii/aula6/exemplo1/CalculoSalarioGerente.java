package br.com.pedro.aula6.exemplo1;

public class CalculoSalarioGerente implements RegraDeCalculo{

    @Override
    public double calcularSalario(double salarioBase) {
        return salarioBase;
    }
}
