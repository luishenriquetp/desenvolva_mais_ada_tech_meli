package br.com.pedro.aula6.exemplo1;

public interface RegraDeCalculo {
    double calcularSalario(double salarioBase);
}
