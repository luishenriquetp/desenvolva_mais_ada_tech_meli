package br.com.pedro.aula6.exemplo2;

public interface Formatador {
    String formatar(String texto);
}
