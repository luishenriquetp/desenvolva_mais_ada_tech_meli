package br.com.pedro.aula6.exemplo2;

public class TextoSimples implements Formatador {
    @Override
    public String formatar(String texto) {
        return texto;
    }
}
