package br.com.pedro.aula6.exercicio;

public class Internacional implements TipoEntrega{
    @Override
    public double valorFrete() {
        return 50;
    }
}
