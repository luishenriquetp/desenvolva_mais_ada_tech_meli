package br.com.pedro.aula6.exercicio;

public interface CalculoFinalPedido {
    double calcular(double valorPedido);
}
