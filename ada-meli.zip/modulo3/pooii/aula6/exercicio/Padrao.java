package br.com.pedro.aula6.exercicio;

public class Padrao implements TipoEntrega{
    @Override
    public double valorFrete() {
        return 10;
    }
}
