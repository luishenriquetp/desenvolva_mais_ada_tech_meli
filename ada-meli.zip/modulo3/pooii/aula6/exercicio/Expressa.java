package br.com.pedro.aula6.exercicio;

public class Expressa implements TipoEntrega{
    @Override
    public double valorFrete() {
        return 20;
    }
}
