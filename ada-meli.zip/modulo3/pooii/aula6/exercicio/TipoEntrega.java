package br.com.pedro.aula6.exercicio;

public interface TipoEntrega {
    double valorFrete();
}
