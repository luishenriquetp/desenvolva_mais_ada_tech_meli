package CalculadorImcComPOO;

public class Paciente{

    String nome;
    double peso;
    double altura;

    // Construtor
    Paciente(String nome, double peso, double altura){
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
    }

}