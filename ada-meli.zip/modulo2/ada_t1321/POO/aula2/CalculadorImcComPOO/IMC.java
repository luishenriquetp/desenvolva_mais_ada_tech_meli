package CalculadorImcComPOO;

public class IMC{
    double imc;

    IMC(double imc){
        this.imc = imc;
    }

    public String getCategoria(){
        if (imc < 10) {
            return "Abaixo";
        } else if (imc >= 10 && imc <= 25) {
            return "Média";
        } else {
            return "Acima";
        }
    }
}
