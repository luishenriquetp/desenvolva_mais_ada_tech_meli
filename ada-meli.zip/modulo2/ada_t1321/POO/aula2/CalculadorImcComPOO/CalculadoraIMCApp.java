package CalculadorImcComPOO;


public class CalculadoraIMCApp{
    public static void main (String[] args) {
        String nome = "Luís";
        double peso = 95;
        double altura = 1.73;



        Paciente p = new Paciente(nome, peso, altura);
        IMC imc = CalculadoraIMC.calcular(p);

        imprimir(p, imc);
    }

    static void imprimir(Paciente p, IMC imc) {
        System.out.println("Paciente: " + p.nome);
        System.out.println("Peso: " + String.format("%.2f", p.peso) + " kg");
        System.out.println("Altura: " + String.format("%.2f", p.altura) + " m");
        System.out.println("IMC: " + String.format("%.2f - %s", imc.imc, imc.getCategoria()));

    }
}