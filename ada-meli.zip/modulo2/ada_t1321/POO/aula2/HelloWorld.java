class HelloWorld{

    public static void main(String[] qualquerCoisa){
        System.out.println("Olá! " + qualquerCoisa[0] + ", " + qualquerCoisa[1]);
    }

}