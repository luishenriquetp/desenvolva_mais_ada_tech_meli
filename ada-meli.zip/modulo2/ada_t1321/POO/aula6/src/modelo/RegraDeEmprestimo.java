package modelo;

public enum RegraDeEmprestimo {

    CURTA_DURACAO, MEDIA_DURACAO, LONGA_DURACAO

}
