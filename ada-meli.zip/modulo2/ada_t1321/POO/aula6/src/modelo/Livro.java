package modelo;

;
public class Livro {

    String titulo;
    String autor;
    String editora;
    Integer ano;
    String categoria;
    public RegraDeEmprestimo regraDeEmprestimo;

}
