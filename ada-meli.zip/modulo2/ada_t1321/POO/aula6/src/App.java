import modelo.recibo.ReciboEmprestimo;
import modelo.recibo.ReciboEmprestimoFactory;

class App {

    static void main(String[] args) {

        ReciboEmprestimo recibo = ReciboEmprestimoFactory.criarRecibo(null, null);


    }

}
