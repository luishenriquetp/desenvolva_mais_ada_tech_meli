class App {

    static void main(String[] args) {
         Livro livro = new Livro();
         livro.autor = "Marcel Tanuri";
         livro.titulo = "O vendedor de códigos";

          Livro outroLivro = new Livro() ;      ;

    }

}
