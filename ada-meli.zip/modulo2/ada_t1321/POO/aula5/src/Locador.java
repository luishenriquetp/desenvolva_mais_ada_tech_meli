class Locador {

    String nome;

    String cpf; // poderia ser Integer? 00044158454

    String dataDeNascimento;

    String nomeDaMae;

    String email;

    String telefone;

    String endereco;

}
