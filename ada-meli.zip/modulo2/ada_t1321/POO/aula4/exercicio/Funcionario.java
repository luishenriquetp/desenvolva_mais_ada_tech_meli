// TAD Abstração
class Funcionario{
    // TAD
    DadosPessoais dadosPessoais;
    // TAD
    DadosContratuais dadosContratuais;
}