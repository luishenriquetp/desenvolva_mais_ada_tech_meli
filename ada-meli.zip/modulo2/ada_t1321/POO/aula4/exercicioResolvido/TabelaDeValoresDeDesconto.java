class TabelaDeValoresDeDesconto{

    static final double SALARIO_ESCALAO_1 = 2000.00;
    static final double DESCONTO_ESCALAO_1 = 0.10;
    
    static final double SALARIO_ESCALAO_2 = 5000.00;
    static final double DESCONTO_ESCALAO_2 = 0.15;
    
    static final double DESCONTO_ESCALAO_3 = 0.20;

    static final double SALARIO_LIMITE_DESCONTO_VT = 2500.00;
    static final double DESCONTO_VT = 0.06;

}