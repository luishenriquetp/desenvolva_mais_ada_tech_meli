class DadosContratuais{
    String cargo;
    double salarioBase;
    boolean valeTransporte;
}