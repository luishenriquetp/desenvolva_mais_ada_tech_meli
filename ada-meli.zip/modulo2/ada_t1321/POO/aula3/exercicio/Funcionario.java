class Funcionario{
    DadosPessoais dadosPessoais;
    DadosContratuais dadosContratuais;
}