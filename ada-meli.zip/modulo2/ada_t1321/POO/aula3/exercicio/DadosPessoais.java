class DadosPessoais{
    String nome;
    String dataNascimento;

}