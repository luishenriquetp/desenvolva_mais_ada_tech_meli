class Paciente{

    String nome;
    double peso;
    double altura;

}

// convenção que as classes comecem com Maiuscula, e também que as variaveis e metodos (funções) minusculas