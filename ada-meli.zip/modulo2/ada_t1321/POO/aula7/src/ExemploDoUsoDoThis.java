public class ExemploDoUsoDoThis {

    public static void main(String[] args) {

        Pedido.fecharConta();

    }
}
