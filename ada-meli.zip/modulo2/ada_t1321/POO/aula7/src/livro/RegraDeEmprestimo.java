package livro;

public enum RegraDeEmprestimo {

    CURTA_DURACAO, MEDIA_DURACAO, LONGA_DURACAO

}
