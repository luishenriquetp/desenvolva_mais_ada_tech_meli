# CalculadoraIMC

compilação
```
javac CalculadoraIMC.java
```

exemplo de execução
```
java CalculadoraIMC -n "Marcel Tanuri" -a 1.88 -p 93
```
