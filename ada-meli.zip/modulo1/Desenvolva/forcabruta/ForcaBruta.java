import java.util.Scanner;

public class ForcaBruta {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String senha="";

        while (true){
            System.out.println("Digite uma senha de 4 dígitos positivos");
            senha = entrada.nextLine();

            if (senha.length() == 4){
                boolean isNumeric = true;
                for (int i = 0; i < senha.length(); i++) {
                    if (!Character.isDigit(senha.charAt(i))) {
                        isNumeric = false;
                        break;
                    }
                }
                if (isNumeric) {
                    break;
                } else {
                    System.out.println("Senha invalida, digite novamente");
                }
            } else {
                System.out.println("Senha invalida, digite novamente");
            }
        }

        int tentativas = 0;

        long inicio = System.currentTimeMillis();

        String senhaLocalizada = "";

        for (int i = 0; i <= 9999; i++) {
                tentativas++;
                String tentativa = String.format("%04d", i);

                if (tentativa.equals(senha)) {
                    senhaLocalizada = tentativa;
                    break;
                }
        }

        long fim = System.currentTimeMillis();
        long tempoGasto = fim - inicio;

        System.out.println("Tentativas: " + tentativas);
        System.out.println("Tempo Gasto: " + tempoGasto);
        System.out.println("Senha Localizada: " + senhaLocalizada);

        entrada.close();
    }
}