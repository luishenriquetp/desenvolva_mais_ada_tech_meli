# Soma dos Elementos da Matriz

## Descrição do Problema
Crie uma matriz NxN, preencha com valores inteiros e calcule a soma de todos os elementos.