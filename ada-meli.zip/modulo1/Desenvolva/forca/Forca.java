import java.util.Scanner;

public class Forca {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int counter = 0;
        int index = (int) (Math.random() * 5);
        String[] lista = {"Carro", "Moto", "Navio", "Trem", "Avião"};
        String word = lista[index];
        String palpite;

        System.out.println("Bem vindos ao jogo da forca!\n");
        System.out.println("Regras:");
        System.out.println("Digite apenas uma letra por vez;");
        System.out.println("Letras com acentuação são consideradas letras distintas, por exemplo, 'a' é diferente de 'ã'.\n");

        for (int i = 0; i < word.length(); index++) {
            counter++;
            i++;
        }

        String[] blank = new String[counter];

        for (int j = 0; j < blank.length; j++) {
            blank[j] = "_";
        }

        System.out.println("Tente adivinhar uma letra na palavra:\n");

        int tentativas = 0;
        while (true) {
            palpite = sc.nextLine();
            if (palpite.length() == 1) {
                while(true) {
                    int counterTrue = 0;
                    for (int k = 0; k < blank.length; k++) {
                        if (palpite.equalsIgnoreCase(word.substring(k, k + 1))) {
                            System.out.println("Acertou! Digite mais um palpite:");
                            blank[k] = palpite;
                            System.out.println((String.join("", blank)));
                            counterTrue++;
                        }
                    }
                    if ((String.join("", blank)).equalsIgnoreCase(word)) {
                        break;

                    }
                    if (tentativas == 5) {
                        break;
                    }
                    if (counterTrue == 0) {
                        System.out.println("Errou! Tente de novo: ");
                        tentativas++;
                    }
                    palpite = sc.nextLine();
                }
            }
            if (tentativas == 5) {
                System.out.println("Você perdeu!");
                break;
            }
            if ((String.join("", blank)).equalsIgnoreCase(word)) {
                System.out.println("Você acertou, parabéns!");
                break;
            }
            System.out.println("Você precisa digitar apenas uma letra:");
        }
    }
}

