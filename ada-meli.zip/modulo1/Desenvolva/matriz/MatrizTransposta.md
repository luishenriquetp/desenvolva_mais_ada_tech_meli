# Matriz Transposta

## Descrição do Problema
Construa a matriz transposta de uma matriz 3x3. A transposta é obtida ao trocar as linhas pelas colunas.

## Exemplo 1
**Entrada:** </br>
1 2 3 </br>
4 5 6 </br>
7 8 9 </br>

**Saida:** </br>
1 4 7  </br>
2 5 8  </br>
3 6 9  </br>
