# Diagonal Principal de uma Matriz

## Descrição do Problema
Exiba apenas os elementos da diagonal principal de uma matriz quadrada.