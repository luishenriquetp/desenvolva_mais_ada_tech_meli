package br.com.projeto_modulo4.taskmanager;

import br.com.projeto_modulo4.enums.Status;
import java.time.LocalDate;

public class Task {
    private String title;
    private String description;
    private LocalDate limitDate;
    private Status status;

    public Task(String title, String description, LocalDate limitDate, Status status) {
        this.title = title;
        this.description = description;
        this.limitDate = limitDate;
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getLimitDate() {
        return limitDate;
    }

    public Status getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Tarefa: " + title + " | Descrição: " + description + " | Data Limite: " + limitDate + " | Status: " + status;
    }
}