package br.com.projeto_modulo4.taskmanager;
import br.com.projeto_modulo4.enums.Status;


import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;


public class TasksManager {
    private List<Task> tasks = new ArrayList<>();


    public void addTask(Task task) {
        tasks.add(task);
    }

    public List<Task> listTasks() {
        return tasks.stream()
                .sorted(Comparator.comparing(Task::getLimitDate))
                .collect(Collectors.toList());
    }

    public List<Task> filterByStatus(Status status) {
        return tasks.stream()
                .filter(t -> t.getStatus() == status)
                .collect(Collectors.toList());
    }

    public boolean removeTask(String title) {
        return tasks.removeIf(t -> t.getTitle().equalsIgnoreCase(title));
    }

    public List<Task> dueDateTasks() {
        LocalDate now = LocalDate.now();
        return tasks.stream()
                .filter(task -> ChronoUnit.HOURS.between(now.atStartOfDay(), task.getLimitDate().atStartOfDay()) <= 24)
                .collect(Collectors.toList());
    }
}