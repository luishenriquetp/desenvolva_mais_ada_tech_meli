package br.com.projeto_modulo4.enums;



public enum Status {
    PENDENTE,
    EM_ANDAMENTO,
    CONCLUIDO;

}