package br.com.projeto_modulo4.app;

import java.util.Scanner;

public class ReadString {
    public static String readString(Scanner scanner, String mensagem) {
        System.out.print(mensagem);
        return scanner.nextLine().trim();
    }
}
