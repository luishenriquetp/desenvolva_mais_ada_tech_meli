package br.com.projeto_modulo4.app;

import br.com.projeto_modulo4.enums.Status;

import java.util.Scanner;

public class ReadStatus {
    public static Status readStatus(Scanner scanner, String mensagem) {
        while (true) {
            try {
                System.out.print(mensagem);
                return Status.valueOf(scanner.nextLine().toUpperCase());
            } catch (IllegalArgumentException e) {
                System.out.println("Erro: Status inválido. Escolha entre PENDENTE, EM_ANDAMENTO ou CONCLUIDO.");
            }
        }
    }
}
