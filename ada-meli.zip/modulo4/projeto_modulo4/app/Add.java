package br.com.projeto_modulo4.app;

import br.com.projeto_modulo4.taskmanager.TasksManager;
import br.com.projeto_modulo4.taskmanager.Task;
import br.com.projeto_modulo4.enums.Status;

import static br.com.projeto_modulo4.app.ReadStatus.readStatus;
import static br.com.projeto_modulo4.app.ReadString.readString;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Add {
    public void add(Scanner scanner, TasksManager manager) {
        System.out.println("\nCadastro de Tarefa");
        String title = readString(scanner, "Título: ");
        String description = readString(scanner, "Descrição: ");
        LocalDate limitDate = readData(scanner);
        Status status = readStatus(scanner, "Status (PENDENTE, EM_ANDAMENTO, CONCLUIDO): ");

        manager.addTask(new Task(title, description, limitDate, status));
        System.out.println("Tarefa adicionada com sucesso!");
    }

    private LocalDate readData(Scanner scanner) {
        while (true) {
            try {
                System.out.print("Data limite (YYYY-MM-DD): ");
                LocalDate data = LocalDate.parse(scanner.nextLine());
                if (data.isBefore(LocalDate.now())) {
                    System.out.println("Erro: A data limite não pode estar no passado!");
                } else {
                    return data;
                }
            } catch (DateTimeParseException e) {
                System.out.println("Erro: Formato de data inválido. Use YYYY-MM-DD.");
            }
        }
    }
}
