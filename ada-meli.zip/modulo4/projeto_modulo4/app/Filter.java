package br.com.projeto_modulo4.app;

import br.com.projeto_modulo4.taskmanager.TasksManager;
import br.com.projeto_modulo4.enums.Status;

import java.util.Scanner;

import static br.com.projeto_modulo4.app.ReadStatus.readStatus;

public class Filter {
    public void filter(Scanner scanner, TasksManager manager) {
        Status filtro = readStatus(scanner, "\nFiltrar tarefas por status (PENDENTE, EM_ANDAMENTO, CONCLUIDO): ");
        manager.filterByStatus(filtro).forEach(System.out::println);
    }
}
