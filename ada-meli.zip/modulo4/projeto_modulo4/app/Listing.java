package br.com.projeto_modulo4.app;

import br.com.projeto_modulo4.taskmanager.TasksManager;

public class Listing {
    public void listing(TasksManager manager) {
        System.out.println("\nTarefas cadastradas:");
        manager.listTasks().forEach(System.out::println);
    }
}
