package br.com.projeto_modulo4.app;

import br.com.projeto_modulo4.taskmanager.TasksManager;

import java.util.Scanner;

import static br.com.projeto_modulo4.app.ReadString.readString;

public class Remover {
    public void remover(Scanner scanner, TasksManager manager) {
        String titulo = readString(scanner, "Digite o título da tarefa a ser removida: ");
        if (manager.removeTask(titulo)) {
            System.out.println("Tarefa removida com sucesso!");
        } else {
            System.out.println("Tarefa não encontrada.");
        }
    }
}
