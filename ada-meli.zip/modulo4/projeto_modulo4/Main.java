package br.com.projeto_modulo4;

import br.com.projeto_modulo4.app.Add;
import br.com.projeto_modulo4.taskmanager.TasksManager;
import br.com.projeto_modulo4.taskmanager.Task;
import br.com.projeto_modulo4.app.Listing;
import br.com.projeto_modulo4.app.Filter;

import br.com.projeto_modulo4.app.Remover;

import java.util.*;




public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TasksManager manager = new TasksManager();

        while (true) {
            System.out.println("\nBem vindo ao manager de Tarefas Inteligente!");
            List<Task> tarefasProximas = manager.dueDateTasks();
            if (!tarefasProximas.isEmpty()) {
                System.out.println("\nTarefas próximas do vencimento!");
                tarefasProximas.forEach(System.out::println);
            }

            System.out.println("\nMenu:");
            System.out.println("1 - Adicionar");
            System.out.println("2 - Listar tarefas");
            System.out.println("3 - Filtrar tarefas por status");
            System.out.println("4 - Remover tarefa");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = lerInteiro(scanner);

            switch (opcao) {
                case 1:
                    new Add().add(scanner, manager);
                    break;
                case 2:
                    new Listing().listing(manager);
                    break;
                case 3:
                    new Filter().filter(scanner, manager);
                    break;
                case 4:
                    new Remover().remover(scanner, manager);
                    break;
                case 5:
                    System.out.println("Saindo...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    private static int lerInteiro(Scanner scanner) {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Entrada inválida. Digite um número inteiro: ");
            }
        }
    }









}