package br.com.ada.desenvolva.solid.behaviour;

public interface Floatable {

    void floatz();

}
