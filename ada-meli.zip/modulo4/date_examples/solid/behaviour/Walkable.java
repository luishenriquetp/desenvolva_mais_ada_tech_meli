package br.com.ada.desenvolva.solid.behaviour;

public interface Walkable {

    void walk();

}
