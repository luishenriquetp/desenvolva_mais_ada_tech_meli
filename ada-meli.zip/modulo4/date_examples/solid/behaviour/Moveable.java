package br.com.ada.desenvolva.solid.behaviour;

public interface Moveable {

    void move();

}
