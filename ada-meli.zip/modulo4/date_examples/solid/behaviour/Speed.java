package br.com.ada.desenvolva.solid.behaviour;

public interface Speed {

    void increase(float value);

    void decrease(float value);

}
