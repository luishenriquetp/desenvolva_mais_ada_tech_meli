package br.com.ada.desenvolva.solid.behaviour;

public interface Flyable {

    void fly();

}
