package br.com.ada.desenvolva.repository;

import java.util.List;

public interface Reader<T> {

    List<T> read();

}
