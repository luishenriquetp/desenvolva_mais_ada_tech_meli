package br.com.ada.desenvolva.repository;

public interface Delete<T> {

    void delete(T object);

}
