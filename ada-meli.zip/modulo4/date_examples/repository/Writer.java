package br.com.ada.desenvolva.repository;

public interface Writer<T> {

    void write(T object);

}
