Exercicios

Salário - Calcule o salário semanal de um funcionário com base na quantidade 
de horas que ele trabalhou. Lembre-se que cada dia pode ter um valor de hora diferente, logo, 
o valor da hora deve ser solicitado ao usuário.

Deve ser solicitado o dia trabalhado, horário de entrada e saída para 
cada periódo e também o valor da hora no dia.

git@github.com:william-cesar-santos1/date-examples.git 
